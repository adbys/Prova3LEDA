package adt.bst;


public class BSTImpl<T extends Comparable<T>> implements BST<T> {

   protected BSTNode<T> root;

   public BSTImpl() {
      root = new BSTNode<T>();
   }

   public BSTNode<T> getRoot() {
      return this.root;
   }

   @Override
   public boolean isEmpty() {
      return root.isEmpty();
   }

   @Override
   public int height() {

      if (this.isEmpty()) {
         return -1;
      } else {
         return findHeight(this.root);
      }

   }

   public int findHeight(BSTNode<T> node) {

      if (node.isEmpty()) {
         return -1;
      }

      int heightLeft = this.findHeight((BSTNode<T>) node.getLeft());
      int heightRight = this.findHeight((BSTNode<T>) node.getRight());

      if (heightLeft > heightRight) {

         return heightLeft + 1;

      } else {

         return heightRight + 1;
      }
   }

   @Override
	public BSTNode<T> search(T element) {
		if (this.getRoot().equals(element)) {
			return this.getRoot();
		} else {
			return this.search(element, this.getRoot());
		}

	}

	private BSTNode<T> search(T element, BSTNode<T> node) {
		if (node.isEmpty()) {
			return node;
		}

		if (element.equals(node.getData())) {

			return node;

		} else {
			if (element.compareTo(node.getData()) > 0) {
				return this.search(element, (BSTNode<T>) node.getRight());
			} else {
				return this.search(element, (BSTNode<T>) node.getLeft());
			}
		}
	}

   @Override
   public void insert(T element) {
      if (this.isEmpty()) {
         this.root = new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
               .parent(this.root).build();
         return;
      }

      this.insert(this.root, element);
   }

   private void insert(BSTNode<T> node, T element) {
	   
      if (node.getData().compareTo(element) < 0) {
         if (node.getRight().isEmpty()) {
            node.setRight(new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
                  .parent(node).build());
            
            return;
         }
         
         
         this.insert((BSTNode<T>) node.getRight(), element);
      
      } else {
      
    	  if (node.getLeft().isEmpty()) {
            node.setLeft(new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
                  .parent(node).build());
          
            return;
         }
    	  
         this.insert((BSTNode<T>) node.getLeft(), element);
      }

   }

   @Override
   public BSTNode<T> maximum() {
      if (this.isEmpty())
         return null;

      return this.maximum(this.root);

   }

   private BSTNode<T> maximum(BSTNode<T> node) {
      if (node.getRight().isEmpty())
         return node;

      return this.maximum((BSTNode<T>) node.getRight());
   }

   @Override
   public BSTNode<T> minimum() {
      if (this.isEmpty())
         return null;

      return this.minimum(this.root);
   }

   private BSTNode<T> minimum(BSTNode<T> node) {
      if (node.getLeft().isEmpty())
         return node;

      return this.minimum((BSTNode<T>) node.getLeft());
   }

   @Override
   public BSTNode<T> sucessor(T element) {
      BSTNode node = this.search(element);

      if (node.isEmpty())
         return null;

      if (!node.getRight().isEmpty())
         return this.minimum((BSTNode<T>) node.getRight());
      else {
         BSTNode<T> aux = node;
         while (aux.getParent().getRight().equals(aux)) {
            aux = (BSTNode<T>) node.getParent();
         }

         return (BSTNode<T>) aux.getParent();
      }
   }

   @Override
   public BSTNode<T> predecessor(T element) {
      BSTNode node = this.search(element);
      
      if (node.isEmpty())
    	  return null;

      if (!node.getLeft().isEmpty())
         return this.maximum((BSTNode<T>) node.getLeft());
      else {
         BSTNode<T> aux = node;
         while (!aux.getParent().isEmpty() && aux.getParent().getLeft().equals(aux)) {
            aux = (BSTNode<T>) aux.getParent();
         }

         if (aux.isEmpty()) {
            return null;
         }

         if (aux.getParent().isEmpty()) {
            return null;
         }

         return (BSTNode<T>) aux.getParent();
      }
   }

   @Override
   public void remove(T element) {
      if (element == null) {
         return;
      }
      
      BSTNode<T> node = this.search(element);
      
      if (node.isEmpty()) {
         return;
      }

      if (node.equals(this.root)) {
         removerRaiz(node);
         return;
      }

      if (node.isLeaf()) {
         removerFolha(node);
         return;
      }

      if (!node.getLeft().isEmpty() && !node.getRight().isEmpty()) {
         
    	 removerGrauDois(node);
         return;
         
      } else {
         removerGrauUm(node);
         return;
      }
   }

   private void removerRaiz(BSTNode<T> node) {
	   
      if (node.getLeft().isEmpty() && node.getRight().isEmpty()) {
         
    	  this.removerFolha(node);
         
      } else if (!node.getLeft().isEmpty() && node.getRight().isEmpty()) {
    	 
    	  this.root = (BSTNode<T>) node.getLeft();
    	  return;
    	  
      } else if (node.getLeft().isEmpty() && !node.getRight().isEmpty()) {
      
    	 this.root = (BSTNode<T>) node.getRight();
         return;
      
      } else {
         
    	  removerGrauDois(node);
         
    	  return;
      }
   }

   private void removerFolha(BSTNode<T> node) {
      node.setData(null);
   }

   private void removerGrauUm(BSTNode<T> node) {
	   
      if (!node.getLeft().isEmpty()) {
         
    	  node.getLeft().setParent(node.getParent());
         
         if (node.getParent().getLeft().equals(node)) {

        	 node.getParent().setLeft(node.getLeft());
         
         } else {
         
        	 node.getParent().setRight(node.getLeft());
         
         }
         
         return;
         
      } else {
    	  
         node.getRight().setParent(node.getParent());
         
         if (node.getParent().getLeft().equals(node)) {
         
        	 node.getParent().setLeft(node.getRight());
         
         } else {
         
        	 node.getParent().setRight(node.getRight());
         }
         
         return;
      }
   }

   private void removerGrauDois(BSTNode<T> node) {
	   
      BSTNode<T> sucessor = this.sucessor(node.getData());
      
      BSTNode<T> predecessor = this.predecessor(node.getData());
      
      if (sucessor != null) {
    	  T data = sucessor.getData();
    	  
    	  remove(sucessor.getData());
    	  
    	  node.setData(data);
    	  
      } else {
    	  
    	  T data = predecessor.getData();
    	  
    	  remove(predecessor.getData());
    	  
    	  node.setData(data);
    	  
      }
      
   }

   @Override
   public T[] preOrder() {
       if (isEmpty())
           return (T[]) new Comparable[0];

       T[] array = (T[]) new Comparable[this.size()];

       preOrder(this.root, array, 0);

       return array;
   }

   private int preOrder(BSTNode<T> node, T[] array, int index) {
       array[index++] = node.getData();

       if (!node.getLeft().isEmpty())
           index = preOrder((BSTNode<T>) node.getLeft(), array, index);

       if (!node.getRight().isEmpty())
           index = preOrder((BSTNode<T>) node.getRight(), array, index);

       return index;
   }

   @Override
   public T[] order() {
       if (isEmpty())
           return (T[]) new Comparable[0];

       T[] array = (T[]) new Comparable[this.size()];

       order(this.root, array, 0);

       return array;
   }

   private int order(BSTNode<T> node, T[] array, int index) {
       if (!node.getLeft().isEmpty())
           index = order((BSTNode<T>) node.getLeft(), array, index);

       array[index++] = node.getData();

       if (!node.getRight().isEmpty())
           index = order((BSTNode<T>) node.getRight(), array, index);

       return index;
   }

   @Override
   public T[] postOrder() {
       if (isEmpty())
           return (T[]) new Comparable[0];

       T[] array = (T[]) new Comparable[this.size()];

       postOrder(this.root, array, 0);

       return array;
   }

   private int postOrder(BSTNode<T> node, T[] array, int index) {
       if (!node.getLeft().isEmpty())
           index = postOrder((BSTNode<T>) node.getLeft(), array, index);

       if (!node.getRight().isEmpty())
           index = postOrder((BSTNode<T>) node.getRight(), array, index);

       array[index++] = node.getData();

       return index;
   }
   
   /**
    * This method is already implemented using recursion. You must understand
    * how it work and use similar idea with the other methods.
    */
   @Override
   public int size() {
      return size(root);
   }

   private int size(BSTNode<T> node) {
      int result = 0;
      // base case means doing nothing (return 0)
      if (!node.isEmpty()) { // indusctive case
         result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
      }
      return result;
   }

}