package adt.bst;

import java.util.ArrayList;

public class BSTImpl<T extends Comparable<T>> implements BST<T> {

   protected BSTNode<T> root;

   public BSTImpl() {
      root = new BSTNode<T>();
   }

   public BSTNode<T> getRoot() {
      return this.root;
   }

   @Override
   public boolean isEmpty() {
      return root.isEmpty();
   }

   @Override
   public int height() {
      return 0;
   }

   @Override
   public BSTNode<T> search(T element) {
      if (this.isEmpty())
         return this.root;

      if (this.root.getData().equals(element))
         return this.root;

      return this.search(this.root, element);
   }

   private BSTNode<T> search(BSTNode<T> node, T element) {

      if (node.getData().equals(element))
         return node;

      if (node.isLeaf() && !node.getData().equals(element))
         return new BSTNode<T>();

      if (node.getData().compareTo(element) < 0) {
         return this.search((BSTNode<T>) node.getRight(), element);
      } else {
         return this.search((BSTNode<T>) node.getLeft(), element);
      }

   }

   @Override
   public void insert(T element) {
      if (this.isEmpty()) {
         this.root = new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
               .parent(this.root).build();
         return;
      }

      this.insert(this.root, element);
   }

   private void insert(BSTNode<T> node, T element) {
      if (node.getData().compareTo(element) < 0) {
         if (node.getRight().isEmpty()) {
            node.setRight(new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
                  .parent(node).build());
            return;
         }
         this.insert((BSTNode<T>) node.getRight(), element);
      } else {
         if (node.getLeft().isEmpty()) {
            node.setLeft(new BSTNode.Builder().data(element).left(new BSTNode<T>()).right(new BSTNode<T>())
                  .parent(node).build());
            return;
         }
         this.insert((BSTNode<T>) node.getLeft(), element);
      }

   }

   @Override
   public BSTNode<T> maximum() {
      if (this.isEmpty())
         return null;

      return this.maximum(this.root);

   }

   private BSTNode<T> maximum(BSTNode<T> node) {
      if (node.getRight().isEmpty())
         return node;

      return this.maximum((BSTNode<T>) node.getRight());
   }

   @Override
   public BSTNode<T> minimum() {
      if (this.isEmpty())
         return null;

      return this.minimum(this.root);
   }

   private BSTNode<T> minimum(BSTNode<T> node) {
      if (node.getLeft().isEmpty())
         return node;

      return this.minimum((BSTNode<T>) node.getLeft());
   }

   @Override
   public BSTNode<T> sucessor(T element) {
      BSTNode node = this.search(element);

      if (node == null)
         return null;

      if (!node.isEmpty() && !node.getRight().isEmpty())
         return this.minimum((BSTNode<T>) node.getRight());
      else {
         BSTNode<T> aux = node;
         while (!aux.isEmpty() && aux.getParent().getRight().equals(aux)) {
            aux = (BSTNode<T>) node.getParent();
         }

         return (BSTNode<T>) aux.getParent();
      }
   }

   @Override
   public BSTNode<T> predecessor(T element) {
      BSTNode node = this.search(element);

      if (!node.isEmpty() && !node.getLeft().isEmpty())
         return this.maximum((BSTNode<T>) node.getLeft());
      else {
         BSTNode<T> aux = node;
         while (!node.isEmpty() && !aux.getParent().isEmpty() && aux.getParent().getLeft().equals(aux)) {
            aux = (BSTNode<T>) aux.getParent();
         }

         if (aux.isEmpty()) {
            return null;
         }

         if (aux.getParent().isEmpty()) {
            return null;
         }

         return (BSTNode<T>) aux.getParent();
      }
   }

   @Override
   public void remove(T element) {
      BSTNode<T> node = this.search(element);

      if (node == null)
         return;
      
      this.remove(node);

      
      }



   private void remove(BSTNode<T> node) {
      if (node.isLeaf()) {
    	  
         if (node.getParent().getLeft().equals(node)) {
            node.getParent().setLeft(new BSTNode.Builder().build());
         } else {
            node.getParent().setRight(new BSTNode.Builder().build());
         }
         node.setParent(null);
         return;
         
      } else if (node.getLeft().isEmpty() || node.getRight().isEmpty()) {
         
    	  if (node.getData().compareTo(node.getParent().getData()) < 0) {

    		  if (!node.getLeft().isEmpty()) {
    			  node.getParent().setLeft(node.getLeft());
    			  node.setLeft(null);
    		  } else {
    			  BSTNode<T> aux = (BSTNode<T>) node.getRight();
    			  aux.setParent(node.getParent());
    			  node.getParent().setLeft(aux);
    			  node.setLeft(null);
    			  aux.setLeft(new BSTNode.Builder().build());
    			  aux.setRight(new BSTNode.Builder().build());
    		  }

         } else {
        	 
        	 if (!node.getLeft().isEmpty()) {
        		 node.getParent().setRight(node.getLeft());
        		 node.setRight(null);
        	 } else {
        		 node.getParent().setRight(node.getRight());
        		 node.setLeft(null);
        	 }
        	 
           
         }
         node.setParent(null);
         return;
      } else {
    	  
    	  this.removeGrau2(node);
    	  
      }

   }

   private void removeGrau2(BSTNode<T> node) {
	   
	BSTNode<T> sucessor = this.sucessor(node.getData());
	BSTNode<T> predecessor = this.predecessor(node.getData());
	
	if (!sucessor.isEmpty()) {
		T nodeValue = node.getData();
		node.setData(sucessor.getData());
		sucessor.setData(nodeValue);
		this.remove(sucessor);
		return;
	}
	
	if (!predecessor.isEmpty()) {
		T nodeValue = node.getData();
		node.setData(predecessor.getData());
		predecessor.setData(nodeValue);
		this.remove(predecessor);
		return;
	}
	
   }

@Override
   public T[] preOrder() {

      if (this.isEmpty())
         return (T[]) new Comparable[0];

      ArrayList<T> array = this.preOrder(this.root);
      T[] retorno = (T[]) new Comparable[array.size()];
      for (int i = 0; i < array.size(); i++) {
         retorno[i] = array.get(i);
      }

      return retorno;
   }

   private ArrayList<T> preOrder(BSTNode<T> node) {
      ArrayList<T> array = new ArrayList<T>();
      if (node.isEmpty())
         return array;
      if (node.isLeaf()) {
         array.add(node.getData());
         return array;
      }

      else {
         array.add(node.getData());
         array.addAll(this.order((BSTNode<T>) node.getLeft()));
         array.addAll(this.order((BSTNode<T>) node.getRight()));
      }
      return array;

   }

   @Override
   public T[] order() {

      if (this.isEmpty())
         return (T[]) new Comparable[0];

      ArrayList<T> array = this.order(this.root);
      T[] retorno = (T[]) new Comparable[array.size()];
      for (int i = 0; i < array.size(); i++) {
         retorno[i] = array.get(i);
      }

      return retorno;

   }

   private ArrayList<T> order(BSTNode<T> node) {

      ArrayList<T> array = new ArrayList<T>();
      if (node.isEmpty())
         return array;
      if (node.isLeaf()) {
         array.add(node.getData());
         return array;
      }

      else {
         array.addAll(this.order((BSTNode<T>) node.getLeft()));
         array.add(node.getData());
         array.addAll(this.order((BSTNode<T>) node.getRight()));
      }
      return array;

   }

   @Override
   public T[] postOrder() {

      if (this.isEmpty())
         return (T[]) new Comparable[0];

      ArrayList<T> array = this.order(this.root);
      T[] retorno = (T[]) new Comparable[array.size()];
      for (int i = 0; i < array.size(); i++) {
         retorno[i] = array.get(i);
      }

      return retorno;
   }

   private ArrayList<T> postOrder(BSTNode<T> node) {
      ArrayList<T> array = new ArrayList<T>();
      if (node.isEmpty())
         return array;
      if (node.isLeaf()) {
         array.add(node.getData());
         return array;
      }

      else {
         array.addAll(this.order((BSTNode<T>) node.getLeft()));
         array.addAll(this.order((BSTNode<T>) node.getRight()));
         array.add(node.getData());
      }
      return array;

   }

   /**
    * This method is already implemented using recursion. You must understand
    * how it work and use similar idea with the other methods.
    */
   @Override
   public int size() {
      return size(root);
   }

   private int size(BSTNode<T> node) {
      int result = 0;
      // base case means doing nothing (return 0)
      if (!node.isEmpty()) { // indusctive case
         result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
      }
      return result;
   }

}
